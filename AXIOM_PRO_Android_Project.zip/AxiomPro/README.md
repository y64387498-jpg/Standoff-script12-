# AXIOM PRO

A compact Android Studio project for a Standoff 2 companion-style launcher.

## Included
- Dark red/black interface.
- Central **BAŞLAT** button that launches Standoff 2 if installed.
- ESP Visual Demo and Auto Headshot Demo switches (local UI-only toggles).
- No external libraries or network permissions.

## Build an APK
1. Open this folder in Android Studio.
2. Let Android Studio sync the Gradle project.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## About APK size
The project does not artificially pad the APK. Its final size depends on Android build tools,
device architectures, and included assets. A 29 MB target cannot be guaranteed from source alone.

## Safety
This app does not inject code into Standoff 2, read or modify game memory, automate aiming,
or provide gameplay cheats. The two feature switches are visual demonstrations only.
