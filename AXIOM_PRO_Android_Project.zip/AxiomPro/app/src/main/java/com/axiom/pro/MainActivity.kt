package com.axiom.pro

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 11, 16)
    private val panel = Color.rgb(23, 25, 33)
    private val red = Color.rgb(244, 45, 59)
    private val muted = Color.rgb(155, 159, 171)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(28))
            setBackgroundColor(bg)
        }

        val logo = label("AXIOM", 36f, red, true).apply {
            letterSpacing = .12f
            gravity = Gravity.CENTER
        }
        val subtitle = label("PRO  /  STANDOFF 2 COMPANION", 11f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = .12f
        }
        val status = label("●  SYSTEM READY", 12f, Color.rgb(100, 210, 140), true).apply {
            gravity = Gravity.CENTER
        }

        val featurePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(panel, 18)
        }
        featurePanel.addView(demoSwitch("ESP VISUAL DEMO"))
        featurePanel.addView(separator())
        featurePanel.addView(demoSwitch("AUTO HEADSHOT DEMO"))

        val note = label(
            "Demo switches only change this app's interface. " +
                "They do not read game data, modify memory, or affect gameplay.",
            12f, muted, false
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), dp(18))
        }

        val launch = Button(this).apply {
            text = "BAŞLAT"
            textSize = 18f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(red, 16)
            setOnClickListener { launchGame() }
        }

        page.addView(logo, LinearLayout.LayoutParams(-1, dp(54)))
        page.addView(subtitle, LinearLayout.LayoutParams(-1, dp(26)))
        page.addView(status, LinearLayout.LayoutParams(-1, dp(54)))
        page.addView(space(20))
        page.addView(featurePanel, LinearLayout.LayoutParams(-1, -2))
        page.addView(note, LinearLayout.LayoutParams(-1, -2))
        page.addView(space(8))
        page.addView(launch, LinearLayout.LayoutParams(-1, dp(60)))
        setContentView(page)
    }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage("com.axlebolt.standoff2")
        if (intent == null) {
            Toast.makeText(this, "Standoff 2 bulunamadı veya kurulu değil.", Toast.LENGTH_LONG).show()
        } else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun demoSwitch(title: String) = Switch(this).apply {
        text = title
        textSize = 13f
        setTextColor(Color.WHITE)
        isChecked = false
        setPadding(0, dp(13), 0, dp(13))
        // UI-only demonstration toggle. No game integration.
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun separator() = View(this).apply {
        setBackgroundColor(Color.rgb(53, 55, 65))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
